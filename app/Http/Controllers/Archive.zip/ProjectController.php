<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Project;
use App\Models\Notificationtb;
use Notification;
use App\Notifications\ProjectsNotification;
use App\Models\Comments;
use App\Models\project_metals;
use App\Models\project_motors;
use App\Models\project_others;
use App\Models\project_lasers;
use App\Models\project_assembling_photos;
use App\Models\project_diagram_photos;
use App\Models\project_horizontal_photos;
use App\Models\project_vertical_photos;
use App\Models\Purchases;
use App\Models\project_orders;
use Illuminate\Http\Request;
use DB;

class ProjectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
        $this->middleware('auth');
        $this->middleware('permission:list-project|create-project|edit-projects|delete-projects|assembling-projects', ['only' => ['index','show','PDFDownload','addCmment']]);
        $this->middleware('permission:create-project', ['only' => ['create','store','assembling']]);
        $this->middleware('permission:edit-projects|assembling-projects', ['only' => ['edit','update']]);
        $this->middleware('permission:delete-projects', ['only' => ['destroy']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->user()->cannot('list-project') && $request->user()->can('list-self-project')) {
            $projects = Project::orderBy('created_at', 'DESC')->where('UID',$request->user()->id)->paginate(10);
            return view('pages.requests', compact('projects'));
        }else if($request->user()->can('list-project')){
            $projects = Project::orderBy('created_at', 'DESC')->where('admin',$request->user()->id)->paginate(10);
            return view('pages.requests', compact('projects'));
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function purchases()
    {
        if (auth()->user()->cannot('list-purchases') && auth()->user()->can('list-self-purchases')) {
            $projects = Purchases::select('*')->paginate(10);
            //$project = $orders->project_orders('created_at', 'DESC')->paginate(10);
            return view('pages.purchase_requests', compact('project'));
        }else if(auth()->user()->can('list-purchases')){
            $projects = Purchases::select('*')->paginate(10);
            //$project = $orders->project_orders()->where('project.admin',auth()->user()->id)->orderBy('created_at', 'DESC')->paginate(10);
            return view('pages.purchase_requests', compact('projects'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // create a serial number for the new project init 0000000001
        if($num = Project::latest('ID')->first()){
            $num = str_pad(($num->id+1), 5, '0', STR_PAD_LEFT);
        }else{
            $num = 0;
            $num = str_pad(($num+1), 5, '0', STR_PAD_LEFT);
        }
        $number = date('y').''.$num;
        // gets users to show only admins in the select admin
        $data = User::orderBy('id','DESC')->paginate(100);
        return view('pages.projects.create',compact('data','number'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function assembling(Project $project)
    {
        $data = User::orderBy('id','DESC')->paginate(100);
        return view('pages.projects.assembling',compact('project','data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //$userSchema = User::first();
        $id = auth()->user()->id;
        $dtnow = date('Y-m-d');
        //$inDate = date('Y-m-d', strtotime($dtnow. ' + ' . $request->dtime . ' days'));

        if($num = Project::latest('ID')->first()){
            $num = str_pad(($num->id+1), 5, '0', STR_PAD_LEFT);
        }else{
            $num = 0;
            $num = str_pad(($num+1), 5, '0', STR_PAD_LEFT);
        }
        $number = date('y').''.$num;

        $rb = $request->get('torp');
        if($rb == 'traditional'){
            $rb = 0;
        }
        else{
            $rb = 1;
        }

        // upload the photo for the given project
        if($request->hasfile('photo')){
            $name=$request->photo->getClientOriginalName();
            $newName = date('dmYHis') . '.'.$request->photo->getClientOriginalExtension();
            $request->photo->move(public_path().'/uploads/', $newName);
            $newpht = $newName;
        }

        // inserts new record to projects database

        $dts =
        [
            'NE' => $dtnow,
            'AS' => '',
            'PO' => '',
            'PU' => ''
        ];

        $pid = Project::create([
            'serial_no' => $number,
            'uid' => $id,
            'admin' => $request->adminselect,
            'pname' => $request->pname,
            'photo' => $newpht,
            'length' => $request->L,
            'width' => $request->W,
            'height' => $request->H,
            'unit' => $request->units1,
            'volume' => $request->volume,
            'cubic_unit' => $request->units2,
            'type' => $rb,
            'machine_voltage' => $request->voltage,
            'details' => $request->edetails,
            'totlal' => 0,
            'phases_times' => $dts,
            'daysneed' => $request->dtime,
            'isApproved' => 0,
        ]);

        foreach($request->metals as $key){
            project_metals::create([
                'project_serial_no' => $number,
                'metal_type' => $key['metal'],
                'thickness' => $key['thickness'],
                'unit' => $key['unit'],
                'title' => $key['title'],
            ]);
        }

        foreach($request->motors as $key){
            project_motors::create([
                'project_serial_no' => $number,
                'motor' => $key['motor'],
                'power' => $key['power'],
                'title' => $key['title'],
            ]);
        }

        foreach($request->others as $key){
            project_others::create([
                'project_serial_no' => $number,
                'title' => $key['title'],
                'info' => $key['info'],
                'details' => $key['details'],
            ]);
        }

        project_lasers::create([
            'project_serial_no' => $number ,
            'laser_cutting' => null ,
            'cnc' => null ,
            'torna' => null ,
            'assembling' => null ,
            'electric_and_automation' => null ,
            'total' => null,
        ]);


        $msg = [
            'greeting' => 'Hi '. auth()->user()->name . ',',
            'body' => 'This is the project assigned to you.',
            'thanks' => 'Thank you this is from sawtru.com.tr',
            'actionText' => 'View Project',
            'actionURL' => url('dashboard/projects/'.$pid->id),
            'id' => $pid->id
        ];

        $admin = User::where('id',$request->adminselect)->get();

        // Notify by Email
        Notification::send(auth()->user(), new ProjectsNotification($msg));
        Notification::send($admin, new ProjectsNotification($msg));

        // dd('Task completed!');
        Notificationtb::create([
            'type' => "success",
            'data' => "new Project with SN: ".$number." Has been Created by: ". auth()->user()->name,
            'tousr' => "0",
            'byusr' => $id,
        ]);

        return redirect()->route('projects.create')
                        ->with('success','Project created successfully.');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addComment(Request $request)
    {
        // $userSchema = User::first();
        $id = auth()->user()->id;
        $dtnow = date('Y-m-d H:i:s');
        $inDate = date('Y-m-d', strtotime($dtnow. ' + ' . $request->dtime . ' days'));

        $input = Comments::create([
            'project_serial_no' => $request->serial,
            'byid' => $id,
            'toid' => $request->toid,
            'content' => $request->content,
            'created_at' => $dtnow,
        ]);

        $project = Project::where('serial_no',$request->serial)->get();

        $byusr = User::where('id',$project[0]->uid)->get();
        $tousr = User::where('id',$project[0]->admin)->get();

        $msg = [
            'greeting' => 'Hi '. $byusr[0]->name . ',',
            'body' => auth()->user()->name . ' has Commented ' . $request->content . ' on Project you are assigned on ' . $project[0]->pname,
            'thanks' => 'Thank you this is from sawtru.com.tr',
            'actionText' => 'View Project',
            'actionURL' => url('dashboard/projects/' . $project[0]->id . '/#cmnt' . $input->id),
            'id' => $project[0]->id
        ];
        Notification::send($byusr, new ProjectsNotification($msg));
        Notification::send($tousr, new ProjectsNotification($msg));
        if(auth()->user()->id != $byusr[0]->id && auth()->user()->id != $tousr[0]->id){
            Notification::send(auth()->user(), new ProjectsNotification($msg));
        }

        // dd('Task completed!');
        Notificationtb::create([
            'type' => "success",
            'data' => "new Project with SN: ".$request->serial." Has been Created by: ". auth()->user()->name,
            'tousr' => "0",
            'byusr' => $id,
        ]);

        return response()->json([
            "status" => true,
            "data" => $input
        ]);



    }

    public function destroyComment($id)
    {
        $uid = auth()->user()->id;
        $dt = date('Y-m-d H:i:s');
        $input = Comments::find($id)->update([
            'available' => 0,
            'removed_at' => $dt,
            'removed_by' => $uid
        ]);
        return response()->json([
            "status" => $input,
            "data" => ["id" => $id]
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function show(Project $project)
    {
        $endTimeStamp = $project->drawing_time;
        //$endTimeStamp = strtotime($project->drawing_time);
        //$timeDiff = abs($endTimeStamp - strtotime(date('Y-m-d')));
        //$numberDays = $timeDiff/86400;
        //$numberDays = intval($numberDays);

        return view('pages.projects.show',compact('project'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function edit(Project $project)
    {
        return view('pages.projects.edit',compact('project'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Project $project)
    {
        if(auth()->user()->isAdmin()){
            $dtnow = date('Y-m-d');
            $inDate = date('Y-m-d', strtotime($dtnow. ' + ' . $project->daysneed . ' days'));

            $phs = 'NE';
            switch($project->phase){
                case 0: $phs = 'NE';
                break;
                case 1: $phs = 'AS';
                break;
                case 2: $phs = 'PO';
                break;
                case 3: $phs = 'PU';
                break;
            }

            if($request->approval == 1){
                $dts = $project->phases_times;
                $dts[$phs] = $dtnow;
                $project->update([
                    'due_time' => $inDate,
                    'isApproved' => $request->approval,
                    'phases_times' => $dts,
                ]);
            }elseif($request->approval == -1){
                $project->update([
                    'phase' => ($project->phase-1),
                    'isApproved' => 1,
                ]);
            }
        }elseif ($request->has('assembling')) {
            $id = auth()->user()->id;
            $dtnow = date('Y-m-d');
            $inDate = date('Y-m-d', strtotime($dtnow. ' + ' . $request->dtime . ' days'));

            $serialno = $project->serial_no;

            if($project->phase == 0){
                $newpht='';
                $i=0;

                foreach($request['motors'] as $key){
                    // upload the photo for the given project

                    if(array_key_exists('motorreal', $key)){

                        $name=$key['photo']->getClientOriginalName();
                        $newName = date('dmYHis') . 'mtr' . $i++ . '.'.$key['photo']->getClientOriginalExtension();
                        $key['photo']->move(public_path().'/uploads/', $newName);
                        $newpht = $newName;

                        project_motors::where([
                            ['project_serial_no' ,'=', $serialno],
                            ['motor' ,'=', $key['motorreal']],
                    ])->update([
                        'price' => $key['price'],
                        'qty' => $key['qty'],
                        'total' => $key['total'],
                        'photo' => $newpht,
                        'updated_at' => $dtnow,
                    ]);
                    }else{

                        $name=$key['photo']->getClientOriginalName();
                        $newName = date('dmYHis') . 'mtr' . $i++ . '.'.$key['photo']->getClientOriginalExtension();
                        $key['photo']->move(public_path().'/uploads/', $newName);
                        $newpht = $newName;

                        project_motors::create([
                            'project_serial_no' => $serialno,
                            'motor' => $key['motor'],
                            'power' => $key['power'],
                            'title' => $key['title'],
                            'price' => $key['price'],
                            'qty' => $key['qty'],
                            'total' => $key['total'],
                            'photo' => $newpht,
                        ]);

                    }

                }

                project_assembling_photos::where([
                    ['project_serial_no' ,'=', $serialno],
                ])->delete();

                project_diagram_photos::where([
                    ['project_serial_no' ,'=', $serialno],
                ])->delete();

                project_horizontal_photos::where([
                    ['project_serial_no' ,'=', $serialno],
                ])->delete();

                project_vertical_photos::where([
                    ['project_serial_no' ,'=', $serialno],
                ])->delete();

                $newpht='';
                $i=0;
                foreach($request->file('asd') as $key){
                    // upload the photo for the given project

                    $name=$key->getClientOriginalName();
                    $newName = date('dmYHis') . 'asd' . $i++ . '.'.$key->getClientOriginalExtension();
                    $key->move(public_path().'/uploads/', $newName);
                    $newpht = $newName;

                    project_assembling_photos::create([
                        'project_serial_no' => $serialno,
                        'name' => $newpht,
                    ]);
                }

                $newpht='';
                $i=0;
                foreach($request->file('mtd') as $key){
                    // upload the photo for the given project

                    $name=$key->getClientOriginalName();
                    $newName = date('dmYHis') . 'mtd' . $i++ . '.'.$key->getClientOriginalExtension();
                    $key->move(public_path().'/uploads/', $newName);
                    $newpht = $newName;

                    project_diagram_photos::create([
                        'project_serial_no' => $serialno,
                        'name' => $newpht,
                    ]);
                }

                $newpht='';
                $i=0;
                foreach($request->file('Horizontal') as $key){
                    // upload the photo for the given project

                    $name=$key->getClientOriginalName();
                    $newName = date('dmYHis') . 'Horizontal' . $i++ . '.'.$key->getClientOriginalExtension();
                    $key->move(public_path().'/uploads/', $newName);
                    $newpht = $newName;

                    project_horizontal_photos::create([
                        'project_serial_no' => $serialno,
                        'name' => $newpht,
                    ]);
                }

                $newpht='';
                $i=0;
                foreach($request->file('Vertical') as $key){
                    // upload the photo for the given project

                    $name=$key->getClientOriginalName();
                    $newName = date('dmYHis') . 'Vertical' . $i++ . '.'.$key->getClientOriginalExtension();
                    $key->move(public_path().'/uploads/', $newName);
                    $newpht = $newName;

                    project_vertical_photos::create([
                        'project_serial_no' => $serialno,
                        'name' => $newpht,
                    ]);
                }

                foreach($request->metals as $key){
                    if(project_metals::where([['project_serial_no' ,'=', $serialno],['metal_type', '=', $key['metalreal']]])){
                        project_metals::where([
                            ['project_serial_no' ,'=', $serialno],
                            ['metal_type' ,'=', $key['metalreal']],
                        ])->update([
                            //'thickness' => $key['thickness'],
                            //'title' => $key['title'],
                            'price' => $key['price'],
                            'qty' => $key['qty'],
                            'total' => $key['total'],
                            'updated_at' => $dtnow,
                        ]);
                    }else{
                        project_metals::create([
                            'project_serial_no' => $number,
                            'metal_type' => $key['metal'],
                            'thickness' => $key['thickness'],
                            'unit' => $key['unit'],
                            'title' => $key['title'],
                            'price' => $key['price'],
                            'qty' => $key['qty'],
                            'total' => $key['total'],
                        ]);
                    }
                }

                foreach($request->others as $key){
                    if(project_others::where([['project_serial_no' ,'=', $serialno],['title', '=', $key['titlereal']]])){
                        project_others::where([
                            ['project_serial_no' ,'=', $serialno],
                            ['title' ,'=', $key['titlereal']],
                        ])->update([
                            'price' => $key['price'],
                            'qty' => $key['qty'],
                            'total' => $key['total'],
                            'updated_at' => $dtnow,
                        ]);
                    }else{
                        project_others::create([
                            'project_serial_no' => $number,
                            'title' => $key['title'],
                            'info' => $key['info'],
                            'details' => $key['details'],
                            'price' => $key['price'],
                            'qty' => $key['qty'],
                            'total' => $key['total'],
                        ]);
                    }
                }
                $sum = $request->laserCutting+$request->CNC+$request->Torna+$request->Assembling+$request->eanda;
                project_lasers::where([
                    ['project_serial_no' ,'=', $serialno],
                ])->update([
                    'laser_cutting' => $request->laserCutting ,
                    'cnc' => $request->CNC ,
                    'torna' => $request->Torna ,
                    'assembling' => $request->Assembling ,
                    'electric_and_automation' => $request->eanda ,
                    'total' => $sum,
                ]);
                $project->update([
                    'daysneed' => $request->dtime,
                    'due_time' => null,
                    'phase'=>1,
                    'isApproved' => 0,
                ]);
                Notificationtb::create([
                    'type' => "success",
                    'data' => "new Project with SN: ".$request->serialno." Has been Created by: ". auth()->user()->name,
                    'tousr' => "0",
                    'byusr' => $id,
                ]);


            }elseif($project->phase == 1){

                if($num = Purchases::latest('ID')->first()){
                    $num = str_pad(($num->id+1), 5, '0', STR_PAD_LEFT);
                }else{
                    $num = 0;
                    $num = str_pad(($num+1), 5, '0', STR_PAD_LEFT);
                }
                $number = 'PO'.date('y').''.$num;

                Purchases::create([
                    'serial_no' => $number,
                    'project_serial_no' => $project['serial_no'],
                    'items' => count($project->motors)+count($project->metals)+count($project->others),
                    'status' => 0,
                ]);

                for($i=0;$i<count($project->motors);$i++){
                    project_orders::create([
                        'purchases_serial_no' => $number,
                        'project_serial_no' => $project['serial_no'],
                        'item_id' => $project->motors[$i]->id,
                        'item' => $request['motors'][$i+1]['item'],
                        'Code' => $request['motors'][$i+1]['code'],
                        'details' => $request['motors'][$i+1]['details'],
                        'delivery' => $request['motors'][$i+1]['delivery'] ,
                        'status' => 0,
                    ]);
                }

                for($i=0;$i<count($project->metals);$i++){
                    project_orders::create([
                        'purchases_serial_no' => $number,
                        'project_serial_no' => $project['serial_no'],
                        'item_id' => $project->metals[$i]->id,
                        'item' => $request['metals'][$i+1]['item'],
                        'Code' => $request['metals'][$i+1]['code'],
                        'details' => $request['metals'][$i+1]['details'],
                        'delivery' => $request['metals'][$i+1]['delivery'] ,
                        'status' => 0,
                    ]);
                }

                for($i=0;$i<count($project->others);$i++){
                    project_orders::create([
                        'purchases_serial_no' => $number,
                        'project_serial_no' => $project['serial_no'],
                        'item_id' => $project->others[$i]->id,
                        'item' => $request['others'][$i+1]['item'],
                        'Code' => $request['others'][$i+1]['code'],
                        'details' => $request['others'][$i+1]['details'],
                        'delivery' => $request['others'][$i+1]['delivery'] ,
                        'status' => 0,
                    ]);
                }

                $project->update([
                    'phase'=>2,
                    'isApproved' => 0,
                ]);
            }elseif($project->phase == 2){
                $project->update([
                    'phase'=>3,
                    'isApproved' => 0,
                ]);
            }elseif($project->phase == 3){
                $project->update([
                    'phase'=>4,
                    'isApproved' => 0,
                ]);
            }
        }
        return redirect()->route('projects.index')
                        ->with('success','Project updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Project::where('id', $id)->delete();
        return redirect()->route('projects.index')
                        ->with('success','Project deleted successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function PDFDownload(Project $project){

    }
}

